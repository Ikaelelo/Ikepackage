# Ikepackage
This library was created for the hackathon-404 package

# building this package locally
`python setup.py sdist`

# installing this package from github
`pip install git+https://github.com/Pseukratis/tripackage.git`

# updating this package from github
`pip install --upgrade git+https://github.com/Pseukratis/tripackage.git`
